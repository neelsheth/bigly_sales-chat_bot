<?php

namespace Database\Seeders;

use App\Models\Feature;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class features extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Feature::truncate();
        Feature::insert(
            [
                [
                    'title' => "SMS/MMS Blast",
                    'description' => "Let Bigly set up your marketing campaign to comply with 10DLC so your messages reach your targets every time. (Don't know what 10DLC is? We do. That's an even better reason to use Bigly).",
                ],
                [
                    'title' => "Global Power Dialing",
                    'description' => "Use Bigly's power dialing technology to reach customers three times faster. Call the USA and Canada from anywhere worldwide. Get your entire global team on one phone system. Transfer calls to anyone globally.",
                ],
                [
                    'title' => "Video texting campaigns",
                    'description' => "Has a friend ever sent you a video by text? Cool right? Be one of the first companies to send Instagram type reels to your clients using text. These are the best performing campaigns that we have ever seen!",
                ]
            ]
        );
    }
}
