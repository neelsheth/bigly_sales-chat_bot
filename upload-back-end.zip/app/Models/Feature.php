<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;

class Feature extends Model
{
    use HasFactory;
    protected $fillable = ['title','description	','status'];
    protected $hidden = ['created_at','updated_at'];
    protected $appends = ['status_name'];

    public static $activeCode = 1;
    public static $inactiveCode = 0;

    public static $activeStatus = "Active";
    public static $inactiveStatus = "Inactive";

    public static function getStatus(): Collection
    {
        return collect([
            'active_code' => self::$activeCode,
            'inactive_code' => self::$inactiveCode,
            'active' => self::$activeStatus,
            'inactive' => self::$inactiveStatus,
        ]);
    }
    public static function getStatusList(): array
    {
        return array(
            [ 'code' => self::$activeCode, 'status_name' => self::$activeStatus],
            [ 'code' => self::$inactiveCode, 'status_name' => self::$inactiveStatus]
        );
    }

    public function getStatusNameAttribute(): string
    {
        return ($this->status == self::$activeCode) ? self::$activeStatus : self::$inactiveStatus;
    }


}
