<?php

namespace App\Http\Controllers\API;

use App\Helpers\CommonHelper;
use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Query;
use App\Models\Feature;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class QueryApiController extends Controller
{
    public function index(Request $request){
        $limit = request('limit', 10);
        $offset = request('offset',0);

        $query = Query::select('*');

        if(isset($request->status) && $request->status != ""){
            $query->where('status', request('status'));
        }

        // Apply sorting
        if ($request->has('sort_by')) {
            $sortColumn = request('sort_by', 'id');
            $sortDirection = request('sort_dir', 'desc');
            $query->orderBy($sortColumn, $sortDirection);
        }

        // Get the total count for pagination
        $total = $query->count();
        $queries = $query->skip($offset)->take($limit)->get();

        // dd($queries);

        if(empty($queries)){
            return  CommonHelper::responseError('Query not found.');
        }
        return CommonHelper::responseWithData($queries,$total);

    }

    public function delete(Request $request){
        if(isset($request->id)){
            $query = Query::find($request->id);
            if($query){
                if($query->delete()){
                    return CommonHelper::responseSuccess("Query Deleted Successfully!");
                }else{
                    return CommonHelper::responseError("Failed to delete the Query record!");
                }
            }else{
                return CommonHelper::responseError("Query Already Deleted!");
            }
        }
    }

    public function save(Request $request){
        $validator = Validator::make($request->all(),[
            'customer_id' => 'required',
            'question' => 'required',
        ]);
        if ($validator->fails()) {
            return CommonHelper::responseErrorWithData("Fill all the fields", $validator->errors());
        }

        $feature_id = 4;
        if(isset($request->feature_id)){
            $feature_id = $request->feature_id;
        }

        $question = $request->question;

        // here you have to add https://groq.com/ api for $solution


        $solution = "Lorem Ipsum is simply dummy text of the printing and typesetting industry.";



        $query = new Query();

        $query->customer_id = $request->customer_id;
        $customer = Customer::find($request->customer_id);
        $query->customer_info = json_encode($customer, true);

        $query->feature_id = $feature_id;
        $feature = Feature::find($feature_id);

        $query->feature_info = json_encode($feature, true);

        $query->question = $question;
        $query->solution = $solution;

        if($query->save()){
            return CommonHelper::responseSuccessWithData("Query saved successfully!", $query);
        }else{
            return CommonHelper::responseError("Failed to save the Query record!");
        }
    }


}
