<?php

namespace App\Http\Controllers\API;

use App\Helpers\CommonHelper;
use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\Enquiry;
use App\Models\Feature;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class EnquiryApiController extends Controller
{
    public function index(Request $request){
        $limit = request('limit', 10);
        $offset = request('offset',0);

        $query = Enquiry::select('*');

        if(isset($request->status) && $request->status != ""){
            $query->where('status', request('status'));
        }

        // Apply sorting
        if ($request->has('sort_by')) {
            $sortColumn = request('sort_by', 'id');
            $sortDirection = request('sort_dir', 'desc');
            $query->orderBy($sortColumn, $sortDirection);
        }

        // Get the total count for pagination
        $total = $query->count();
        $enquiries = $query->skip($offset)->take($limit)->get();

        if(empty($enquiries)){
            return  CommonHelper::responseError('Enquiry not found.');
        }
        return CommonHelper::responseWithData($enquiries,$total);

    }

    public function getActive(Request $request){
        $limit = request('limit', 10);
        $offset = request('offset',0);

        $query = Customer::select('*');

        $query->where('status', Customer::$activeCode);

        // Apply sorting
        if ($request->has('sort_by')) {
            $sortColumn = request('sort_by', 'id');
            $sortDirection = request('sort_dir', 'desc');
            $query->orderBy($sortColumn, $sortDirection);
        }

        // Get the total count for pagination
        $total = $query->count();
        $customers = $query->skip($offset)->take($limit)->get();

        if(empty($customers)){
            return  CommonHelper::responseError('Question not found.');
        }
        return CommonHelper::responseWithData($customers,$total);
    }

    public function delete(Request $request){
        if(isset($request->id)){
            $enquiry = Enquiry::find($request->id);
            if($enquiry){
                if($enquiry->delete()){
                    return CommonHelper::responseSuccess("Enquiry Deleted Successfully!");
                }else{
                    return CommonHelper::responseError("Failed to delete the Enquiry record!");
                }
            }else{
                return CommonHelper::responseError("Enquiry Already Deleted!");
            }
        }
    }

    public function save(Request $request){
        $validator = Validator::make($request->all(),[
            'customer_id' => 'required',
            'feature_id' => 'required',
        ]);
        if ($validator->fails()) {
            return CommonHelper::responseErrorWithData("Fill all the fields", $validator->errors());
        }
        $enquiry = new Enquiry();

        $enquiry->customer_id = $request->customer_id;
        $customer = Customer::find($request->customer_id);
        $enquiry->customer_info = json_encode($customer, true);

        $enquiry->feature_id = $request->feature_id;

        $feature = Feature::find($request->feature_id);

        $enquiry->feature_info = json_encode($feature, true);

        $enquiry->status = 1;

        if($enquiry->save()){
            return CommonHelper::responseSuccessWithData("Enquiry saved successfully!", $enquiry);
        }else{
            return CommonHelper::responseError("Failed to save the Enquiry record!");
        }
    }

    public function update(Request $request){
        $validator = Validator::make($request->all(),[
            'customer_id' => 'required',
            'feature_id' => 'required',
        ]);

        if ($validator->fails()) {
            return CommonHelper::responseErrorWithData("Fill all the fields", $validator->errors());
        }

        $enquiry = Customer::find($request->id);

        $enquiry->customer_id = $request->customer_id;
        $customer = Customer::find($request->customer_id);
        $enquiry->customer_info = json_encode($customer, true);

        $enquiry->feature_id = $request->feature_id;

        $feature = Feature::find($request->feature_id);

        $enquiry->feature_info = json_encode($feature, true);

        if($customer->save()){
            return CommonHelper::responseSuccessWithData("Customer updated successfully!", $enquiry);
        }else{
            return CommonHelper::responseError("Failed to update the Customer record!");
        }
    }
}
