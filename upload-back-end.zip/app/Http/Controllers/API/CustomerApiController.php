<?php

namespace App\Http\Controllers\API;

use App\Helpers\CommonHelper;
use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CustomerApiController extends Controller
{
    public function index(Request $request){
        $limit = request('limit', 10);
        $offset = request('offset',0);

        $query = Customer::select('*');

        if(isset($request->status) && $request->status != ""){
            $query->where('status', request('status'));
        }

        // Apply search filters
        if ($request->has('search')) {
            $search = $request->input('search', null);
            $query->where(function ($query) use ($search) {
                $query->where('name', 'like', '%'.$search.'%')
                    ->orWhere('mobile', 'like', '%'.$search.'%')
                    ->orWhere('company', 'like', '%'.$search.'%')
                    ->orWhere('company', 'like', '%'.$search.'%');
            });
        }

        // Apply sorting
        if ($request->has('sort_by')) {
            $sortColumn = request('sort_by', 'id');
            $sortDirection = request('sort_dir', 'desc');
            $query->orderBy($sortColumn, $sortDirection);
        }

        // Get the total count for pagination
        $total = $query->count();
        $customers = $query->skip($offset)->take($limit)->get();



        if(empty($customers)){
            return  CommonHelper::responseError('Customer not found.');
        }
        return CommonHelper::responseWithData($customers,$total);

    }

    public function getActive(Request $request){
        $limit = request('limit', 10);
        $offset = request('offset',0);

        $query = Customer::select('*');

        $query->where('status', Customer::$activeCode);

        // Apply search filters
        if ($request->has('search')) {
            $search = $request->input('search', null);
            $query->where(function ($query) use ($search) {
                $query->where('question', 'like', '%'.$search.'%')
                    ->orWhere('answer', 'like', '%'.$search.'%');
            });
        }

        // Apply sorting
        if ($request->has('sort_by')) {
            $sortColumn = request('sort_by', 'id');
            $sortDirection = request('sort_dir', 'desc');
            $query->orderBy($sortColumn, $sortDirection);
        }

        // Get the total count for pagination
        $total = $query->count();
        $customers = $query->skip($offset)->take($limit)->get();

        if(empty($customers)){
            return  CommonHelper::responseError('Question not found.');
        }
        return CommonHelper::responseWithData($customers,$total);
    }

    public function delete(Request $request){
        if(isset($request->id)){
            $customer = Customer::find($request->id);
            if($customer){
                if($customer->delete()){
                    return CommonHelper::responseSuccess("Customer Deleted Successfully!");
                }else{
                    return CommonHelper::responseError("Failed to delete the Customer record!");
                }
            }else{
                return CommonHelper::responseError("Customer Already Deleted!");
            }
        }
    }

    public function getDataList(){
        $data['status_data'] = Customer::getStatus();
        $data['status_list'] = Customer::getStatusList();

        $total = count($data);
        if($total > 0){
            return CommonHelper::responseWithData($data, $total);
        }else{
            return CommonHelper::responseError("Data not found!");
        }
    }

    public function updateStatus(Request $request){
        if(isset($request->id)){
            $customer = Customer::find($request->id);
            if($customer){
                $customer->status = ($customer->status == Customer::$activeCode) ? Customer::$inactiveCode : Customer::$activeCode;
                if($customer->save()){
                    return CommonHelper::responseSuccess("Customer status updated successfully!");
                }else{
                    return CommonHelper::responseError("Failed to status update the Customer record!");
                }
            }else{
                return CommonHelper::responseError("Customer record not found!");
            }
        }
    }

    public function save(Request $request){
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'mobile' => 'required',
            'email' => 'required',
            'company' => 'required',
        ]);
        if ($validator->fails()) {
            return CommonHelper::responseErrorWithData("Fill all the fields", $validator->errors());
        }
        $customer = new Customer();
        $customer->name = $request->name;
        $customer->mobile = $request->mobile;
        $customer->email = $request->email;
        $customer->company = $request->company;
        $customer->status = $request->status ?? Customer::$activeCode;

        if($customer->save()){
            return CommonHelper::responseSuccessWithData("Customer saved successfully!", $customer);
        }else{
            return CommonHelper::responseError("Failed to save the Customer record!");
        }
    }

    public function update(Request $request){
        $validator = Validator::make($request->all(),[
            'name' => 'required',
            'mobile' => 'required',
            'email' => 'required',
            'company' => 'required',
        ]);

        if ($validator->fails()) {
            return CommonHelper::responseErrorWithData("Fill all the fields", $validator->errors());
        }

        $customer = Customer::find($request->id);

        $customer->name = $request->name;
        $customer->mobile = $request->mobile;
        $customer->email = $request->email;
        $customer->company = $request->company;

        if($customer->save()){
            return CommonHelper::responseSuccessWithData("Customer updated successfully!", $customer);
        }else{
            return CommonHelper::responseError("Failed to update the Customer record!");
        }
    }
}
