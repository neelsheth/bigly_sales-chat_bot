<?php

namespace App\Http\Controllers\API;

use App\Helpers\CommonHelper;
use App\Http\Controllers\Controller;
use App\Models\Feature;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class FeatureApiController extends Controller
{
    public function index(Request $request){
        $limit = request('limit', 10);
        $offset = request('offset',0);

        $query = Feature::select('*');

        if(isset($request->status) && $request->status != ""){
            $query->where('status', request('status'));
        }

        // Apply search filters
        if ($request->has('search')) {
            $search = $request->input('search', null);
            $query->where(function ($query) use ($search) {
                $query->where('question', 'like', '%'.$search.'%')
                    ->orWhere('answer', 'like', '%'.$search.'%');
            });
        }

        // Apply sorting
        if ($request->has('sort_by')) {
            $sortColumn = request('sort_by', 'id');
            $sortDirection = request('sort_dir', 'desc');
            $query->orderBy($sortColumn, $sortDirection);
        }

        // Get the total count for pagination
        $total = $query->count();
        $features = $query->skip($offset)->take($limit)->get();

        // dd($features);

        if(empty($features)){
            return  CommonHelper::responseError('Question not found.');
        }
        return CommonHelper::responseWithData($features,$total);

    }

    public function getActive(Request $request){
        $limit = request('limit', 10);
        $offset = request('offset',0);

        $query = Feature::select('*');

        $query->where('status', Feature::$activeCode);

        // Apply search filters
        if ($request->has('search')) {
            $search = $request->input('search', null);
            $query->where(function ($query) use ($search) {
                $query->where('question', 'like', '%'.$search.'%')
                    ->orWhere('answer', 'like', '%'.$search.'%');
            });
        }

        // Apply sorting
        if ($request->has('sort_by')) {
            $sortColumn = request('sort_by', 'id');
            $sortDirection = request('sort_dir', 'desc');
            $query->orderBy($sortColumn, $sortDirection);
        }

        // Get the total count for pagination
        $total = $query->count();
        $features = $query->skip($offset)->take($limit)->get();

        if(empty($features)){
            return  CommonHelper::responseError('Question not found.');
        }
        return CommonHelper::responseWithData($features,$total);
    }

    public function delete(Request $request){
        if(isset($request->id)){
            $faq = Feature::find($request->id);
            if($faq){
                if($faq->delete()){
                    return CommonHelper::responseSuccess("Question Deleted Successfully!");
                }else{
                    return CommonHelper::responseError("Failed to delete the Question record!");
                }
            }else{
                return CommonHelper::responseError("Question Already Deleted!");
            }
        }
    }

    public function getDataList(){
        $data['status_data'] = Feature::getStatus();
        $data['status_list'] = Feature::getStatusList();

        $total = count($data);
        if($total > 0){
            return CommonHelper::responseWithData($data, $total);
        }else{
            return CommonHelper::responseError("Data not found!");
        }
    }

    public function updateStatus(Request $request){
        if(isset($request->id)){
            $feature = Feature::find($request->id);
            if($feature){
                $feature->status = ($feature->status == Feature::$activeCode) ? Feature::$inactiveCode : Feature::$activeCode;
                if($feature->save()){
                    return CommonHelper::responseSuccess("Feature status updated successfully!");
                }else{
                    return CommonHelper::responseError("Failed to status update the Feature record!");
                }
            }else{
                return CommonHelper::responseError("Feature record not found!");
            }
        }
    }

    public function save(Request $request){
        $validator = Validator::make($request->all(),[
            'question' => 'required',
            'answer' => 'required',
        ]);
        if ($validator->fails()) {
            return CommonHelper::responseErrorWithData($validator->errors());
        }
        $faq = new FAQ();
        $faq->question = $request->question;
        $faq->answer = $request->answer;
        $faq->status = $request->status ?? FAQ::$activeCode;

        if($faq->save()){
            return CommonHelper::responseSuccess("Feature saved successfully!");
        }else{
            return CommonHelper::responseError("Failed to save the Feature record!");
        }
    }

    public function update(Request $request){
        $validator = Validator::make($request->all(),[
            'question' => 'required',
            'answer' => 'required',
            'status' => 'required',
        ]);
        if ($validator->fails()) {
            return CommonHelper::responseErrorWithData($validator->errors(), "Fill all the fields");
        }

        $faq = FAQ::find($request->id);
        $faq->question = $request->question;
        $faq->answer = $request->answer;
        if($faq->save()){
            return CommonHelper::responseSuccess("Feature updated successfully!");
        }else{
            return CommonHelper::responseError("Failed to update the Feature record!");
        }
    }
}
