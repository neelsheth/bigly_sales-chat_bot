<?php

use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;


function currentTimestamp(){
    return \Carbon\Carbon::now()->toDateTimeString();
}
