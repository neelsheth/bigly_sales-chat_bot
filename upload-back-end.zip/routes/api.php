<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});


Route::group(['prefix' => 'features'], function () {

    Route::get('/', [\App\Http\Controllers\API\FeatureApiController::class, 'index']);
    Route::get('setup', [\App\Http\Controllers\API\FeatureApiController::class, 'getDataList'])->name('features.setup');
    Route::post('delete', [\App\Http\Controllers\API\FeatureApiController::class, 'delete'])->name('features.delete');
    Route::post('update_status', [\App\Http\Controllers\API\FeatureApiController::class, 'updateStatus'])->name('features.update_status');

    Route::get('active', [\App\Http\Controllers\API\FeatureApiController::class, 'getActive'])->name('features.active');
    Route::post('save', [\App\Http\Controllers\API\FeatureApiController::class, 'save'])->name('features.save');
    Route::post('update', [\App\Http\Controllers\API\FeatureApiController::class, 'update'])->name('features.update');
});

Route::group(['prefix' => 'customers'], function () {

    Route::get('/', [\App\Http\Controllers\API\CustomerApiController::class, 'index']);
    Route::get('setup', [\App\Http\Controllers\API\CustomerApiController::class, 'getDataList'])->name('customers.setup');
    Route::post('delete', [\App\Http\Controllers\API\CustomerApiController::class, 'delete'])->name('customers.delete');
    Route::post('update_status', [\App\Http\Controllers\API\CustomerApiController::class, 'updateStatus'])->name('customers.update_status');

    Route::get('active', [\App\Http\Controllers\API\CustomerApiController::class, 'getActive'])->name('customers.active');
    Route::post('save', [\App\Http\Controllers\API\CustomerApiController::class, 'save'])->name('customers.save');
    Route::post('update', [\App\Http\Controllers\API\CustomerApiController::class, 'update'])->name('customers.update');
});

Route::group(['prefix' => 'enquiries'], function () {
    Route::get('/', [\App\Http\Controllers\API\EnquiryApiController::class, 'index']);
    Route::post('delete', [\App\Http\Controllers\API\EnquiryApiController::class, 'delete'])->name('enquiries.delete');
    Route::post('save', [\App\Http\Controllers\API\EnquiryApiController::class, 'save'])->name('enquiries.save');
    Route::post('update', [\App\Http\Controllers\API\EnquiryApiController::class, 'update'])->name('enquiries.update');
});

Route::group(['prefix' => 'queries'], function () {
    Route::get('/', [\App\Http\Controllers\API\QueryApiController::class, 'index']);
    Route::post('delete', [\App\Http\Controllers\API\QueryApiController::class, 'delete'])->name('queries.delete');
    Route::post('save', [\App\Http\Controllers\API\QueryApiController::class, 'save'])->name('queries.save');
    Route::post('update', [\App\Http\Controllers\API\QueryApiController::class, 'update'])->name('queries.update');
});

